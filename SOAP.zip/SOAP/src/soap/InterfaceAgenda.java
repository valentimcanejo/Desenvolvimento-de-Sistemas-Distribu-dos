package soap;
import javax.jws.WebService;
import java.util.ArrayList;
import javax.jws.WebMethod;

@WebService
public interface InterfaceAgenda {
    @WebMethod public ArrayList<Contatos> retornaContatos();
    @WebMethod public void criaContato(String nome, String email, String telefone);
    @WebMethod public void apagarContatos(String nome, String email, String telefone);
    @WebMethod public int contarContatos();
    
}
