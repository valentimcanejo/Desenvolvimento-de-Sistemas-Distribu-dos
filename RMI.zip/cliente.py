import Pyro4


ns = Pyro4.locateNS()
URL = ns.lookup('objeto')
server = Pyro4.Proxy(URL)

while(True):
	idade = int(input("Digite sua idade: "))
	fcp = int(input("Digite sua frequencia cardiaca em repouso: "))
	
	
	calculo = ''

	if idade >= 18 and idade <= 25:
		if fcp >= 56 and fcp <= 61:
			calculo = 'Excelente'
		elif fcp >= 62 and fcp <= 65:
			calculo = 'Boa'
		elif fcp >= 70 and fcp <= 73:
			calculo = 'Normal'
		elif fcp >= 74 and fcp <= 81:
			calculo = 'Ruim'
		elif fcp > 82:
			calculo = 'Muito Ruim'
		print("Sua frequencia cardiaca esta: ", calculo)
		
	
		
	elif idade >= 26 and idade <= 35:
		if fcp >= 55 and fcp <= 61:
			calculo = "Excelente"
		elif fcp >= 62 and fcp <= 65:
			calculo = "Boa"
		elif fcp >= 71 and fcp <= 74:
			calculo = "Normal"
		elif fcp >= 75 and fcp <= 81:
			calculo = "Ruim"
		elif fcp > 82:
			calculo = "Muito Ruim"
		print("Sua frequencia cardiaca esta: ", calculo)
		
		
	elif idade >= 36 and idade <= 45:
		if fcp >= 57 and fcp <= 62:
			calculo = "Excelente"
		elif fcp >= 63 and fcp <= 66:
			calculo = "Boa"
		elif fcp >= 71 and fcp <= 75:
			calculo = "Normal"
		elif fcp >= 76 and fcp <= 82:
			calculo = "Ruim"
		elif fcp > 83:
			calculo = "Muito Ruim"
		print("Sua frequencia cardiaca esta: ", calculo)
		
		
	elif idade >= 46 and idade <= 55:
		if fcp >= 58 and fcp <= 63:
			calculo = "Excelente"
		elif fcp >= 64 and fcp <= 67:
			calculo = "Boa"
		elif fcp >= 72 and fcp <= 76:
			calculo = "Normal"
		elif fcp >= 77 and fcp <= 82:
			calculo = "Ruim"
		elif fcp > 84:
			calculo = "Muito Ruim"
		print("Sua frequencia cardiaca esta: ", calculo)
		
		
	elif idade >= 56 and idade <= 65:
		if fcp >= 57 and fcp <= 61:
			calculo = "Excelente"
		if fcp >= 62 and fcp <= 67:
			calculo = "Boa"
		elif fcp >= 72 and fcp <= 75:
			calculo = "Normal"
		elif fcp >= 76 and fcp <= 81:
			calculo = "Ruim"
		elif fcp > 82:
			calculo = "Muito Ruim"
		print("Sua frequencia cardiaca esta: ", calculo)
		
	server.fc(calculo)	
			
print("Sua frequencia esta:", calculo)
