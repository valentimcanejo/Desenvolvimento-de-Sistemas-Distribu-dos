from zeep import Client


class Contatos:
	pass

def criaContato():
	agenda = Contatos()
	agenda.nome = input("Digite o nome do novo contato:\n")
	agenda.email = input("Digite o email:\n")
	agenda.telefone = input("Digite o telefone:\n")
	return agenda

def main():
	client = Client('http://localhost:9876/agenda?wsdl')
	
	print('   Digite um número correspondente a cada opção\n')
	while True:
		print('\n   -------------Agenda de Contatos-------------\n')
		print("   1 - Registrar novo contato\n")
		print("   2 - Listar contatos registrados\n")
		print("   3 - Apagar lista de contatos\n")
		print("   4 - Ver número de contatos registrados na agenda\n")
		print("   5 - Sair do programa\n")
		op = input('Digite a opção: ')
		if op == '1':
			contatos = criaContato()
			client.service.criaContato(contatos.nome, contatos.email, contatos.telefone)
			print(contatos.nome)
		elif op == '2':
			listar = client.service.retornaContatos()
			print("---- Contatos ----")

			for contatos in listar:				
				print(" Nome:", contatos.nome)
				print(" Email:", contatos.email)
				print(" Telefone:", contatos.telefone)
				print("------------------")
		elif op == '3':
			client.service.apagarContatos()
			
		elif op == '4':
			contador = client.service.contarContatos()
			print(" \nNúmero de contatos na agenda: ", contador)
			
		elif op == '5':
			break
		else:
			print("erro")












if __name__ == '__main__':
	main()