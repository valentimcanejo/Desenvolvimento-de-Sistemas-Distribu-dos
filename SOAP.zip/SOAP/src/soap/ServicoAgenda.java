package soap;

import java.util.ArrayList;
import javax.jws.WebService;

@WebService(endpointInterface = "soap.InterfaceAgenda")
public class ServicoAgenda implements InterfaceAgenda{

    private ContatosDAO contatosDAO = new ContatosDAO();
    
    @Override
    public ArrayList<Contatos> retornaContatos() {
        return contatosDAO.listaContatos();
    }
    @Override
    public void criaContato(String nome, String email, String telefone) {
        contatosDAO.criaContato(nome, email, telefone);
    }
    @Override
    public void apagarContatos(String nome, String email, String telefone) {
        contatosDAO.apagarContatos(nome, email, telefone);
    }

    
    @Override
    public int contarContatos() {
        return contatosDAO.contarContatos();
    }
    
    
}
