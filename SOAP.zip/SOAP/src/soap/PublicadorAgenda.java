package soap;

import soap.PublicadorAgenda;
import javax.xml.ws.Endpoint;

public class PublicadorAgenda {
    public static void main(String[] args){
        Endpoint.publish("http://localhost:9876/agenda", new ServicoAgenda());
    }
}
