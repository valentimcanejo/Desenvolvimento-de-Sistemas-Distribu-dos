import Pyro4

@Pyro4.expose
class CalculoFC:
	def fc(self, calculo):
		print("A sua frequencia cardiaca em repouso esta:", calculo)
		
		return calculo
		
daemon = Pyro4.Daemon()

URL = daemon.register(CalculoFC)
ns = Pyro4.locateNS()
ns.register('objeto', URL)
print("Servidor criado, esperando conexão com o cliente...")

daemon.requestLoop()
