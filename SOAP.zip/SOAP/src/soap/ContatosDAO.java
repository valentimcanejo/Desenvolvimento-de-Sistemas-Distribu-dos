package soap;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class ContatosDAO {
    private static Map<Long, Contatos> Contatos = new LinkedHashMap<>();
    private static Long counter;
    
    public ContatosDAO(){
        counter = 0L;
    }

    public ArrayList<Contatos> listaContatos(){
        return new ArrayList<>(Contatos.values());
    }
    public void criaContato(String nome, String email, String telefone){
        counter += 1L;
        Contatos.put(counter, new Contatos(counter, nome, email, telefone));
    }
   
    public void apagarContatos(String nome, String email, String telefone) {
        Contatos.clear();
    }
    
    int contarContatos() {
       
        return Contatos.size();
    }

  
   
}
